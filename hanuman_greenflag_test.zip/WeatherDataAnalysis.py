import pandas as pd
import os
import glob
import sys

parquet_output_file_name="weather.parquet"
pyarrow_output_file_name='pyarrow_output.csv'
df_concat=pd.DataFrame()
error_codes={100:"Columns counts Mismatch in ",101:"Headers Mismatch in ",102:"Missing Data or Null Values in the following fields "}
output_fields=['Region','ObservationDate','ScreenTemperature']

def validate_data():
   ''' Validate the required fields in output_fields list are not missing any values.
       If they are missing analysis need to be done whether to do a forward/backward fill for the missing data.
   '''
   field_with_null_values=[ key for key,value in df_concat[output_fields].isna().any().to_dict().items() if value ]
   if len(field_with_null_values) > 0:
      print(error_codes[102] + str(field_with_null_values))
      return False
   return True

def process_using_pyarrow():
   import pyarrow as pa
   import pyarrow.parquet as pq
   #Writing only the required fields(output_fields) into the table.
   weather_data_table = pa.Table.from_pandas(df_concat[output_fields])
   pq.write_table(weather_data_table,parquet_output_file_name,compression='BROTLI')   
   df=pq.read_pandas(parquet_output_file_name).to_pandas()  
   o=df[df["ScreenTemperature"]==df["ScreenTemperature"].max()]
   o[output_fields].to_csv(pyarrow_output_file_name,header=True,index=False)

if __name__ == '__main__':
    
   target_directory=sys.argv[1]
   os.chdir(target_directory) 
   #Concatenate the list of DataFrames into a Singel DataFrame
   df_concat=pd.concat(map(pd.read_csv, glob.glob(os.path.join('', "weather*.csv"))))
   if validate_data():
      print("Validated the data for missing/null values in the required fields"+str(output_fields))
      #process_using_spark(nthhottest_day)
      #print("Successfully written the output using SparkSQL into "+spark_output_file_name)
      process_using_pyarrow()
      print("Successfully written the output using pyarrow into "+pyarrow_output_file_name)      
   else:
      print("Some of the required fields are missing data and needs further analysis.")
